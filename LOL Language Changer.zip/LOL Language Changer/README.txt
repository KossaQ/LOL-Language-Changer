To use LOL Language Changer you first need to find the path to the LeagueClient.exe file which is in your league of legends folder. The base path is contained in the path file, but it may differ from your path. To change it, click the reset button and search for LeagueClient.exe. Then select a language from the list. if everything went according to plan, the Open League Of Legends button will appear. Click it and enjoy the changed language.

IMPORTANT:
Once you have chosen the path to the file, you don't have to do it every time. After clicking Select Path, the program will automatically download it from the file.
For the first time after changing the language, you always have to start the program via a button or a created shortcut. Every time after that, the starting method doesn't matter.
If the path file is deleted, the program will stop working. To fix this, just create it manually.
The code of the entire program is contained in the file with the .py extension. Feel free to modify it however you like.

CHANGELOG:
-Path file will now create itself if do not exists.
-"Open League Of Legends" Button will now disappear when the reset button is clicked
-Choose Path will not be changed into empty path when shutting down
-Select Path will not be changed to empty Path: when the path selection window is closed without selecting it.
-Window cannot be resized now.
-Renamed root variable to window in code file

